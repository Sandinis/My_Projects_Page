#  MY PROJECTS PAGE 

 

  ## Instructions
  1. Create an index file that will hold the navigation menu that will eventually link to all of your best projects you have done this semester:  Quote, MyLifeInPictures, Menu, textWrap, and Gradient.
  2. Create a horizontal navigation bar, don't worry about the links yet we will put those in as we progress through this project.  
  3. Create an img folder
  4. Go to your quote page and download the background image, then upload it into the image folder you created in step 3.
  5. Create a css folder
  6. Go into this css folder and create a new file called <strong>quotestyle.css</strong>.  Copy your entire css file from your old replit quote project into this file.   Change the background image property so it looks like this     <strong> ../img/nameOfYourImageHere</strong>
  7. Create a new file called quote.html and copy the entire html file from your old replit into this file.  Change the link to the css file to the following  <strong> ../css/quotestyle.css    </strong>  
  8.  Go to the index page and link the quote anchor to your quote.html page.     It should look like this
      <br>
  ```python
 <li><a href="quote.html">Quote Page</a></li>
```
  
  9. Repeat steps 4,6-8 for my life in pictures.  Create a new file called lifeInPix.html, etc
  10. Repeat steps 4,6-8 for Menu.  Create a new file called edinaBistro.html etc
  11. Repeat steps 4,6-8 for floatTextWrap.  Create a new file called textWrap.html  etc
  12. Repeat steps 4,6-8 for our Gradient Activity.  Create a new file called Gradient.html etc
  
  13. Once everything is working and propertly linking to each other, finally put a link at the bottom of each project that links back to the original page (that is our index.html).  Make sure you style it in the style.css page.
  14. Style your main index page.
  15. Add in a media query that changes the navigation bar to vertical when your resize the page below 600px.  Hint you will also need to make it a flex display.

```

  